#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QPlainTextEdit>
#include <QSlider>
#include <QScrollBar>
#include <QSpinBox>
#include <QCheckBox>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

protected:
    void closeEvent(QCloseEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private slots:
    void onCursorChanged();
    void onCheckBoxToggled(bool checked);
    void openSettings();
    void loadAndDraw();

private:
    // Задание 1 — редактор + статус
    QPlainTextEdit *textEditor;
    QLabel         *cursorLabel;

    // Задание 3 — виджеты
    QSlider    *slider;
    QScrollBar *scrollBar;
    QSpinBox   *spinBox;
    QCheckBox  *checkBox;
    QLabel     *statusLbl;

    // Задание 4/5 — график
    QLabel           *canvas;
    QVector<double>   m_xData;
    QVector<double>   m_yData;

    void buildUI();
    void buildMenu();
    void drawGraph();
};

#endif
