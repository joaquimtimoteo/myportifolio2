#include "settingsdialog.h"
#include "ui_settingsdialog.h"
#include <QSettings>

SettingsDialog::SettingsDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SettingsDialog)
{
    ui->setupUi(this);
    setWindowTitle("Настройки");
    setModal(true);
    setFixedSize(380, 200);

    loadSettings();

    connect(ui->buttonBox, &QDialogButtonBox::accepted,
            this, &SettingsDialog::onAccepted);
    connect(ui->buttonBox, &QDialogButtonBox::rejected,
            this, &QDialog::reject);
}

SettingsDialog::~SettingsDialog()
{
    delete ui;
}

bool SettingsDialog::saveGeometryEnabled() const
{
    return ui->checkSaveGeometry->isChecked();
}

void SettingsDialog::loadSettings()
{
    QSettings s;
    ui->checkSaveGeometry->setChecked(
        s.value("saveGeometry", false).toBool());
}

void SettingsDialog::saveSettings()
{
    QSettings s;
    s.setValue("saveGeometry",
               ui->checkSaveGeometry->isChecked());
}

void SettingsDialog::onAccepted()
{
    saveSettings();
    accept();
}
