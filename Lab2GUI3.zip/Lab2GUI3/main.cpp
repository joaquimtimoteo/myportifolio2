#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.setApplicationName("Lab2GUI3");
    a.setOrganizationName("QtLab");

    MainWindow w;
    w.show();
    return a.exec();
}
