#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QSettings>
#include <QCloseEvent>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    // Задание 1 — позиция курсора в StatusBar
    void onCursorPositionChanged();

    // Задание 2 — настройки / геометрия
    void openSettings();

    // Задание 4/5 — загрузка файла и построение графика
    void loadFileAndPlot();

    // Задание 6 — демо-график QCustomPlot
    void plotDemo();

    // Задание 3 — CheckBox → Label
    void onCheckBoxToggled(bool checked);

private:
    Ui::MainWindow *ui;
    QLabel         *cursorLabel;
    QCustomPlot    *plot;

    void setupMenuAndToolbar();
    void setupStatusBar();
    void setupPlot();
    void setupWidgetConnections();

    void loadWindowGeometry();
    void saveWindowGeometry();

    void plotDataFromFile(const QString &filePath);
};

#endif // MAINWINDOW_H
