#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "settingsdialog.h"

#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QAction>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QVBoxLayout>
#include <QSettings>
#include <cmath>

// ─────────────────────────────────────────────────────────────
// CONSTRUTOR
// ─────────────────────────────────────────────────────────────
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , cursorLabel(nullptr)
    , plot(nullptr)
{
    ui->setupUi(this);
    setWindowTitle("Lab 2-3: Приложение с GUI");
    setMinimumSize(860, 560);

    setupMenuAndToolbar();
    setupStatusBar();
    setupPlot();
    setupWidgetConnections();
    loadWindowGeometry();

    // Задание 1 — сигнал изменения позиции курсора
    connect(ui->textEditor,
            &QPlainTextEdit::cursorPositionChanged,
            this,
            &MainWindow::onCursorPositionChanged);

    onCursorPositionChanged(); // начальное состояние

    plotDemo(); // показать sin/cos при запуске
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ─────────────────────────────────────────────────────────────
// МЕНЮ И ПАНЕЛЬ ИНСТРУМЕНТОВ
// ─────────────────────────────────────────────────────────────
void MainWindow::setupMenuAndToolbar()
{
    // ── Меню «Файл» ──────────────────────────────
    QMenu *fileMenu = menuBar()->addMenu("Файл");

    QAction *actLoad = new QAction("Загрузить данные...", this);
    actLoad->setShortcut(QKeySequence::Open);
    actLoad->setStatusTip("Загрузить данные из файла и построить график");
    fileMenu->addAction(actLoad);

    QAction *actDemo = new QAction("Показать демо-график", this);
    actDemo->setStatusTip("Построить демонстрационный график sin(x) и cos(x)");
    fileMenu->addAction(actDemo);

    fileMenu->addSeparator();

    QAction *actExit = new QAction("Выход", this);
    actExit->setShortcut(QKeySequence::Quit);
    fileMenu->addAction(actExit);

    // ── Меню «Настройки» ─────────────────────────
    QMenu *settingsMenu = menuBar()->addMenu("Настройки");

    QAction *actSettings = new QAction("Параметры...", this);
    actSettings->setStatusTip("Открыть диалог настроек");
    settingsMenu->addAction(actSettings);

    // ── Панель инструментов ───────────────────────
    QToolBar *tb = addToolBar("Главная");
    tb->setMovable(false);
    tb->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
    tb->addAction(actLoad);
    tb->addAction(actDemo);
    tb->addSeparator();
    tb->addAction(actSettings);

    // ── Соединения ────────────────────────────────
    connect(actLoad,     &QAction::triggered, this, &MainWindow::loadFileAndPlot);
    connect(actDemo,     &QAction::triggered, this, &MainWindow::plotDemo);
    connect(actExit,     &QAction::triggered, this, &QMainWindow::close);
    connect(actSettings, &QAction::triggered, this, &MainWindow::openSettings);
}

// ─────────────────────────────────────────────────────────────
// СТРОКА СОСТОЯНИЯ (StatusBar)
// ─────────────────────────────────────────────────────────────
void MainWindow::setupStatusBar()
{
    cursorLabel = new QLabel("Стр: 1   Кол: 1");
    cursorLabel->setStyleSheet("padding: 0 10px; color: #1565C0;");
    statusBar()->addPermanentWidget(cursorLabel);
    statusBar()->showMessage("Готово", 3000);
}

// ─────────────────────────────────────────────────────────────
// ЗАДАНИЕ 1 — Позиция курсора
// ─────────────────────────────────────────────────────────────
void MainWindow::onCursorPositionChanged()
{
    QTextCursor cursor = ui->textEditor->textCursor();
    int line = cursor.blockNumber() + 1;
    int col  = cursor.columnNumber() + 1;

    // Постоянная метка справа
    cursorLabel->setText(QString("Стр: %1   Кол: %2").arg(line).arg(col));

    // Временное сообщение в статусной строке (2 секунды)
    statusBar()->showMessage(
        QString("Позиция курсора: строка %1, столбец %2")
            .arg(line).arg(col), 2000);
}

// ─────────────────────────────────────────────────────────────
// ЗАДАНИЕ 2 — Геометрия окна
// ─────────────────────────────────────────────────────────────
void MainWindow::loadWindowGeometry()
{
    QSettings s;
    if (s.value("saveGeometry", false).toBool()) {
        restoreGeometry(s.value("windowGeometry").toByteArray());
        restoreState(s.value("windowState").toByteArray());
    }
}

void MainWindow::saveWindowGeometry()
{
    QSettings s;
    if (s.value("saveGeometry", false).toBool()) {
        s.setValue("windowGeometry", saveGeometry());
        s.setValue("windowState",    saveState());
    }
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    saveWindowGeometry();
    event->accept();
}

// ─────────────────────────────────────────────────────────────
// НАСТРОЙКИ
// ─────────────────────────────────────────────────────────────
void MainWindow::openSettings()
{
    SettingsDialog dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        statusBar()->showMessage("Настройки сохранены", 2000);
    }
}

// ─────────────────────────────────────────────────────────────
// ЗАДАНИЕ 3 — Виджеты (CheckBox → Label)
// ─────────────────────────────────────────────────────────────
void MainWindow::setupWidgetConnections()
{
    // Slider ↔ ScrollBar ↔ SpinBox
    connect(ui->slider,
            QOverload<int>::of(&QSlider::valueChanged),
            ui->scrollBar, &QScrollBar::setValue);

    connect(ui->slider,
            QOverload<int>::of(&QSlider::valueChanged),
            ui->spinBox,   &QSpinBox::setValue);

    connect(ui->spinBox,
            QOverload<int>::of(&QSpinBox::valueChanged),
            ui->slider,    &QSlider::setValue);

    // CheckBox → Label
    connect(ui->checkBox, &QCheckBox::toggled,
            this, &MainWindow::onCheckBoxToggled);
}

void MainWindow::onCheckBoxToggled(bool checked)
{
    if (checked) {
        ui->statusLbl->setText("Статус: Вкл  ✓");
        ui->statusLbl->setStyleSheet("color: green; font-weight: bold;");
    } else {
        ui->statusLbl->setText("Статус: Выкл");
        ui->statusLbl->setStyleSheet("color: red; font-weight: bold;");
    }
}

// ─────────────────────────────────────────────────────────────
// ЗАДАНИЕ 4/5 — График из файла
// ─────────────────────────────────────────────────────────────
void MainWindow::setupPlot()
{
    plot = new QCustomPlot;
    plot->setBackground(QColor("#FAFAFA"));
    plot->xAxis->setLabel("X");
    plot->yAxis->setLabel("Y");
    plot->xAxis->setLabelColor(QColor("#333333"));
    plot->yAxis->setLabelColor(QColor("#333333"));
    plot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);
    plot->legend->setVisible(true);

    // Встраиваем в plotWidget
    auto *lay = new QVBoxLayout(ui->plotWidget);
    lay->setContentsMargins(0, 0, 0, 0);
    lay->addWidget(plot);
}

void MainWindow::loadFileAndPlot()
{
    QString path = QFileDialog::getOpenFileName(
        this,
        "Загрузить данные",
        "",
        "Текстовые файлы (*.txt *.csv *.dat);;Все файлы (*)");

    if (path.isEmpty()) return;

    plotDataFromFile(path);
}

void MainWindow::plotDataFromFile(const QString &filePath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Ошибка",
            "Не удалось открыть файл:\n" + filePath);
        return;
    }

    QVector<double> xData, yData;
    QTextStream in(&file);

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();

        // Пропускаем пустые строки и комментарии
        if (line.isEmpty() || line.startsWith('#')) continue;

        // Поддержка форматов: "x y", "x,y", "x;y"
        line.replace(',', ' ');
        line.replace(';', ' ');
        QStringList parts = line.split(' ', Qt::SkipEmptyParts);

        if (parts.size() >= 2) {
            bool okX, okY;
            double x = parts[0].toDouble(&okX);
            double y = parts[1].toDouble(&okY);
            if (okX && okY) {
                xData.append(x);
                yData.append(y);
            }
        }
    }
    file.close();

    if (xData.isEmpty()) {
        QMessageBox::warning(this, "Ошибка",
            "Файл не содержит корректных данных.\n\n"
            "Ожидаемый формат (одна пара на строку):\n"
            "  0.0  1.0\n"
            "  1.0  2.5\n"
            "  2.0  4.0");
        return;
    }

    // Строим график
    plot->clearGraphs();
    plot->addGraph();
    plot->graph(0)->setData(xData, yData);
    plot->graph(0)->setPen(QPen(QColor("#1565C0"), 2));
    plot->graph(0)->setScatterStyle(QCPScatterStyle(
        QCPScatterStyle::ssCircle, QColor("#1565C0"), 5));
    plot->graph(0)->setName("Данные из файла");
    plot->xAxis->setLabel("X");
    plot->yAxis->setLabel("Y");
    plot->rescaleAxes();
    plot->replot();

    statusBar()->showMessage(
        QString("График построен: %1 точек  |  Файл: %2")
            .arg(xData.size())
            .arg(filePath.section('/', -1)),
        5000);
}

// ─────────────────────────────────────────────────────────────
// ЗАДАНИЕ 6 — QCustomPlot демо: sin(x) и cos(x)
// ─────────────────────────────────────────────────────────────
void MainWindow::plotDemo()
{
    const int N = 300;
    QVector<double> x(N), sinY(N), cosY(N);

    for (int i = 0; i < N; i++) {
        x[i]    = -M_PI + i * (2.0 * M_PI / (N - 1));
        sinY[i] = std::sin(x[i]);
        cosY[i] = std::cos(x[i]);
    }

    plot->clearGraphs();

    // sin(x)
    plot->addGraph();
    plot->graph(0)->setData(x, sinY);
    plot->graph(0)->setPen(QPen(QColor("#1565C0"), 2));
    plot->graph(0)->setName("sin(x)");

    // cos(x)
    plot->addGraph();
    plot->graph(1)->setData(x, cosY);
    plot->graph(1)->setPen(QPen(QColor("#C62828"), 2));
    plot->graph(1)->setName("cos(x)");

    plot->legend->setVisible(true);
    plot->xAxis->setLabel("X (радианы)");
    plot->yAxis->setLabel("Y");
    plot->xAxis->setRange(-M_PI, M_PI);
    plot->yAxis->setRange(-1.3, 1.3);
    plot->replot();

    statusBar()->showMessage("Демо-график sin(x) и cos(x) построен", 3000);
}
